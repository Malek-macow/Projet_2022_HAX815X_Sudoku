library(testthat)
library(MALEX)

test_check("MALEX")
